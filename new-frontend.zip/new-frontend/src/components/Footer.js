// src/components/common/Footer.js
import React from 'react';

const Footer = () => (
  <footer>
    <p>© 2025 E-Commerce Website</p>
  </footer>
);

export default Footer;
